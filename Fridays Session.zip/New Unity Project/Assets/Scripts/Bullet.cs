﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    void DestroyObjectDelayed()
    {

        Destroy(this.gameObject, 1);
    }
}